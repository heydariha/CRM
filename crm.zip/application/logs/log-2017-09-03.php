<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-03 00:10:22 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:19:37 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:20:15 --> Could not find the language line "tit_Username"
ERROR - 2017-09-03 00:20:15 --> Could not find the language line "tit_Password"
ERROR - 2017-09-03 00:20:28 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:20:40 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:21:42 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:43:38 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:44:14 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:50:10 --> 404 Page Not Found: Vendore/template
ERROR - 2017-09-03 00:51:42 --> Severity: Parsing Error --> syntax error, unexpected 'form' (T_STRING) C:\xampp\htdocs\codeigniter\crm\application\libraries\General.php 50
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:00:40 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:29 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:02:57 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:03:13 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:06:12 --> 404 Page Not Found: Vendore/calendar
ERROR - 2017-09-03 01:07:57 --> Could not find the language line "tit_Username"
ERROR - 2017-09-03 01:07:57 --> Could not find the language line "tit_Password"
