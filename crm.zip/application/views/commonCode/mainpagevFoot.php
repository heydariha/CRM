					</div>
				</div>
				<!-- FOOTER -->
				<footer>
					<div class="row">
						<div class="col-md-7">
							<p style="font-size:10px;">Copy Right by HAdi  &copy; 2017 </p>
						</div>
						<div class="col-md-5">
							<ul class="social">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul>
						</div>
					</div>
				</footer>
			</div>
		</div>
	</div>
</div>
<!-- MAIN CONTENT -->
<!-- JavaScript -->
<script src="<?php echo base_url('vendore/template/js/jquery.min.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/bootstrap.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/jquery.flexslider.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/jquery.easing.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/jquery.mixitup.min.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/nivo-lightbox.min.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/jquery.appear.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/jquery.inview.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/main.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/contact.js');?>"></script>
<script src="<?php echo base_url('vendore/template/js/animations.js');?>"></script>

<script src1="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src1="<?php echo base_url('vendore/template/js/gmaps.js');?>"></script>

</body>
</html>

<?php
$page->page->footPage();
?>