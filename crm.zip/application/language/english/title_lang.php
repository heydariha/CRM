<?php 
#______________ Data Grid
$lang['tit_view'] = "مشاهده";
$lang['tit_to'] = "تا";
$lang['tit_of'] = "از";
$lang['tit_go_to_first_page'] = "صفحه نخست";
$lang['tit_go_to_previous_page'] = "صفحه قبل";
$lang['tit_page'] = "صفحه";
$lang['tit_go_to_next_page'] = "صفحه بعد";
$lang['tit_go_to_last_page'] = "صفحه آخر";
#______________
$lang['tit_hello'] = "سلام";
$lang['tit_row'] = "ردیف";
$lang['tit_All'] = "همه";
$lang['tit_Personal_Information'] = "اطلاعات فردی";
$lang['tit_Submit'] = "ذخیره";
$lang['tit_Ignore'] = "بی خیال";
$lang['tit_Change_Password'] = "تغییر کلمه عبور";
$lang['tit_Take_care_of_your_password'] = "مواظب نام کاربریتان باشید";
$lang['tit_current_password'] = "کلمه عبور جاری";
$lang['tit_new_password'] = "کلمه عبور جدید";
$lang['tit_repeat_new_password'] = "تکرار کلمه عبور جدید";
$lang['tit_customers_list'] = "لیست مشتریان";
$lang['tit_new_customer'] = "مشتری جدید";
$lang['tit_subscribe_code'] = "کد اشتراک";
$lang['tit_Name'] = "نام";
$lang['tit_Family'] = "نام خانوادگی";
$lang['tit_Email'] = "ایمیل";
$lang['tit_Mobile'] = "موبایل";
$lang['tit_Telephone'] = "تلفن";
$lang['tit_Address'] = "آدرس";
$lang['tit_Edit'] = "ویرایش";
$lang['tit_Delete'] = "حذف";
$lang['tit_Edit_personal_information'] = "ویرایش اطلاعات فردی";
$lang['tit_services'] = "سرویس ها";
$lang['tit_service_date'] = "تاریخ سرویس";
$lang['tit_sort_ASC'] = "مرتب سازی صعودی";
$lang['tit_sort_DESC'] = "مرتب سازی نزولی";
$lang['tit_tech_man'] = "سرویس کار";
$lang['tit_description'] = "توضیحات";
$lang['tit_new_task'] = "فعالیت جدید";
$lang['tit_done_date'] = "تاریخ انجام";
$lang['tit_tasks_list_for'] = "سرویس های انجام شده برای";
$lang['tit_search'] = "جستجو";
$lang['tit_view_all'] = "مشاهده همه";

?>