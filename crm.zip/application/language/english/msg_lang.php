<?php 

$lang['msg_Operation_has_done_successfully'] = "عملیات مورد نظر با موفقیت به پایان رسید"; 
$lang['msg_Error_in_save'] = "خطا در ثبت اطلاعات"; 
$lang['msg_Record_already_exists'] = "رکورد تکراری";
$lang['msg_Error_In_Saving_new_task'] = "خطا در درج سرویس";
?>